import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Role } from '../../common/enums';
import { AuthenticatedUser } from '../../common/interfaces';
import { AccessScopeService } from '../../common/services/access-scope.service';
import { Manager } from '../managers/manager.entity';
import { Tenant } from '../tenants/tenant.entity';
import { UserStore } from '../user-stores/user-store.entity';
import { User } from '../users/user.entity';
import { CreateStoreDto, UpdateStoreDto } from './dto/store.dto';
import { Store } from './store.entity';

@Injectable()
export class StoresService {
  constructor(
    @InjectRepository(Store)
    private readonly storeRepository: Repository<Store>,
    @InjectRepository(Manager)
    private readonly managerRepository: Repository<Manager>,
    @InjectRepository(Tenant)
    private readonly tenantRepository: Repository<Tenant>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(UserStore)
    private readonly userStoreRepository: Repository<UserStore>,
    private readonly accessScope: AccessScopeService,
  ) {}

  async create(requester: AuthenticatedUser, dto: CreateStoreDto): Promise<Store> {
    const tenantId = await this.resolveTenantIdForWrite(requester, dto.tenantId, dto.managerId);
    await this.ensureTenantExists(tenantId);
    const managerId = await this.resolveLegacyManagerIdForWrite(requester, dto.managerId, tenantId);

    const store = this.storeRepository.create({
      name: dto.name.trim(),
      managerId,
      tenantId,
      active: true,
    });

    return this.storeRepository.save(store);
  }

  async findAll(requester: AuthenticatedUser): Promise<Store[]> {
    if (this.accessScope.isPlatformAdmin(requester)) {
      return this.storeRepository.find({
        relations: ['manager'],
        order: { createdAt: 'DESC' },
      });
    }

    if (!requester.tenantId) {
      return [];
    }

    return this.storeRepository.find({
      where: { tenantId: requester.tenantId },
      relations: ['manager'],
      order: { createdAt: 'DESC' },
    });
  }

  async findAccessible(requester: AuthenticatedUser): Promise<Store[]> {
    if (this.accessScope.isPlatformAdmin(requester)) {
      return this.storeRepository.find({
        where: { active: true },
        relations: ['manager'],
        order: { name: 'ASC' },
      });
    }

    if (this.accessScope.isAdmin(requester) || this.accessScope.isManager(requester)) {
      if (!requester.tenantId) {
        return [];
      }

      return this.storeRepository.find({
        where: { tenantId: requester.tenantId, active: true },
        relations: ['manager'],
        order: { name: 'ASC' },
      });
    }

    const links = await this.userStoreRepository.find({
      where: { userId: requester.id },
      relations: ['store', 'store.manager', 'store.tenant'],
      order: { createdAt: 'ASC' },
    });

    return links
      .map((link) => link.store)
      .filter((store): store is Store => !!store && store.active);
  }

  async findOne(id: string, requester: AuthenticatedUser): Promise<Store> {
    const store = await this.findOneUnsafeInternal(id);
    this.accessScope.validateTenantAccess(requester, store.tenantId);
    return store;
  }

  async update(id: string, requester: AuthenticatedUser, dto: UpdateStoreDto): Promise<Store> {
    const store = await this.findOne(id, requester);

    if (dto.name !== undefined) {
      store.name = dto.name.trim();
    }

    if (dto.active !== undefined) {
      store.active = dto.active;
    }

    if (dto.managerId !== undefined) {
      if (!this.accessScope.isPlatformAdmin(requester)) {
        throw new ForbiddenException('Apenas ADMIN pode alterar managerId legado da store');
      }

      await this.ensureManagerExists(dto.managerId);
      store.managerId = dto.managerId;
    }

    if (dto.tenantId !== undefined) {
      if (!this.accessScope.isPlatformAdmin(requester)) {
        throw new ForbiddenException('Apenas PLATFORM_ADMIN pode alterar o tenant da store');
      }

      await this.ensureTenantExists(dto.tenantId);
      await this.ensureStoreCanMoveTenant(store, dto.tenantId);
      store.tenantId = dto.tenantId;
    }

    return this.storeRepository.save(store);
  }

  async toggleActive(id: string, requester: AuthenticatedUser): Promise<Store> {
    const store = await this.findOne(id, requester);
    store.active = !store.active;
    return this.storeRepository.save(store);
  }

  async listUsers(storeId: string, requester: AuthenticatedUser): Promise<Omit<User, 'password'>[]> {
    await this.findOne(storeId, requester);

    const links = await this.userStoreRepository.find({
      where: { storeId },
      relations: ['user'],
      order: { createdAt: 'DESC' },
    });

    return links.map((link) => {
      const { password: _password, ...user } = link.user;
      return user;
    });
  }

  async linkUserToStore(
    storeId: string,
    userId: string,
    requester: AuthenticatedUser,
  ): Promise<UserStore> {
    const store = await this.findOne(storeId, requester);
    const user = await this.findUserForLink(userId);

    this.validateLinkTenant(requester, store, user);

    const existing = await this.userStoreRepository.findOne({
      where: { storeId, userId },
    });
    if (existing) {
      throw new ConflictException('Usuário já vinculado a esta store');
    }

    const link = this.userStoreRepository.create({ storeId, userId });
    return this.userStoreRepository.save(link);
  }

  async unlinkUserFromStore(
    storeId: string,
    userId: string,
    requester: AuthenticatedUser,
  ): Promise<void> {
    const store = await this.findOne(storeId, requester);
    const user = await this.findUserForLink(userId);

    this.validateLinkTenant(requester, store, user);

    const result = await this.userStoreRepository.delete({ storeId, userId });
    if (!result.affected) {
      throw new NotFoundException('Vínculo usuário-store não encontrado');
    }
  }

  private async findOneUnsafeInternal(id: string): Promise<Store> {
    const store = await this.storeRepository.findOne({
      where: { id },
      relations: ['manager', 'tenant'],
    });
    if (!store) {
      throw new NotFoundException('Store não encontrada');
    }

    return store;
  }

  private async findUserForLink(userId: string): Promise<User> {
    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (!user || !user.active) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;
  }

  private async resolveTenantIdForWrite(
    requester: AuthenticatedUser,
    payloadTenantId?: string,
    legacyManagerId?: string,
  ): Promise<string> {
    if (this.accessScope.isPlatformAdmin(requester)) {
      const tenantId = payloadTenantId ?? legacyManagerId;
      if (!tenantId) {
        throw new BadRequestException('tenantId é obrigatório para ADMIN criar store');
      }

      return tenantId;
    }

    if (!(this.accessScope.isAdmin(requester) || this.accessScope.isManager(requester)) || !requester.tenantId) {
      throw new ForbiddenException('Apenas ADMIN ou MANAGER podem gerenciar stores do tenant');
    }

    return requester.tenantId;
  }

  private async resolveLegacyManagerIdForWrite(
    requester: AuthenticatedUser,
    payloadManagerId: string | undefined,
    tenantId: string,
  ): Promise<string> {
    if (payloadManagerId) {
      await this.ensureManagerExists(payloadManagerId);
      return payloadManagerId;
    }

    if (requester.managerId) {
      return requester.managerId;
    }

    const manager = await this.managerRepository.findOne({ where: { id: tenantId } });
    if (manager) {
      return manager.id;
    }

    throw new BadRequestException('managerId legado é obrigatório até a remoção definitiva do campo');
  }

  private async ensureManagerExists(managerId: string): Promise<void> {
    const manager = await this.managerRepository.findOne({ where: { id: managerId } });
    if (!manager || !manager.active) {
      throw new NotFoundException('Manager não encontrado');
    }
  }

  private async ensureTenantExists(tenantId: string): Promise<void> {
    const tenant = await this.tenantRepository.findOne({ where: { id: tenantId } });
    if (!tenant) {
      throw new NotFoundException('Tenant não encontrado');
    }
  }

  private validateLinkTenant(requester: AuthenticatedUser, store: Store, user: User): void {
    if (!user.tenantId || user.tenantId !== store.tenantId) {
      throw new ForbiddenException('Usuário e store precisam pertencer ao mesmo tenant');
    }

    if (!this.accessScope.isPlatformAdmin(requester)) {
      this.accessScope.validateTenantAccess(requester, user.tenantId);
    }

    if ([Role.PLATFORM_ADMIN, Role.ADMIN].includes(user.role)) {
      throw new ForbiddenException('ADMIN não deve ser vinculado a stores');
    }
  }

  private async ensureStoreCanMoveTenant(store: Store, nextTenantId: string): Promise<void> {
    if (store.tenantId === nextTenantId) {
      return;
    }

    const linkedUsers = await this.userStoreRepository.count({ where: { storeId: store.id } });
    if (linkedUsers > 0) {
      throw new BadRequestException('Store com usuários vinculados não pode trocar de manager');
    }
  }
}
